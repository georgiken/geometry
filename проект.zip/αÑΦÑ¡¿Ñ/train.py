a=[]
for i in range(4):
    a.append(float(input()))

print(a)
